import java.io.FileWriter;
import java.io.IOException;


public class WriteToTxt
{
    public String filePath = "boxScore.txt";

    public WriteToTxt(String statCategory)
    {
        try {
            FileWriter writer = new FileWriter(filePath, true);
            writer.write("----" + statCategory + "----\n");
            writer.close();
        }
        catch(IOException e)
        {
            throw new RuntimeException(e);
        }
    }

    public void writeToFile(int stats, String playerName)
    {
        try
        {
            //File is in append mode, "true"
            FileWriter writer = new FileWriter(filePath, true);
            writer.write(playerName + ": ");
            writer.append(stats + "\n");
            writer.close();

        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }
    public void findMax(int[] stats, String[] names, String statCategory)
    {
        int maximum = stats[0];
        int maxPlayer = 0;
        for (int i = 1; i < stats.length; ++i)
        {
            if (stats[i] > maximum)
            {
                maximum = stats[i];
                //"maxPlayer++" is to find which player has the maximum stat
                maxPlayer++;
            }

        }
            try
            {
                //File is in append mode, "true"
                FileWriter writer = new FileWriter(filePath, true);
                writer.write("The highest stat is " + names[maxPlayer] + " with " + maximum + " " + statCategory + "\n" + "\n");
                writer.close();

            }
            catch (IOException e)
            {
                throw new RuntimeException(e);
            }
    }



    public void clearFile()
    {
        try
        {
            //File is in overwrite mode, "false"
            FileWriter writer = new FileWriter(filePath, false);
            writer.close();
        }
        catch (IOException e)
        {
            throw new RuntimeException();
        }
    }
}

