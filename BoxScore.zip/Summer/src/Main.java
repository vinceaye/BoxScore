import java.util.InputMismatchException;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner scnr = new Scanner(System.in);
        boolean stopCondition = true;
        while(stopCondition)
        {
            System.out.println("Type the stat category to be recorded");
            String statCategory = scnr.next().toUpperCase();
            WriteToTxt test = new WriteToTxt(statCategory);
            System.out.println("Type the number of players to be accounted for");
            int playerCount = scnr.nextInt();

            int i = 0;
            int[] playerStats = new int[playerCount];
            String[] playerNames = new String[playerCount];
            while (i < playerCount) {
                System.out.println("Enter stat of Player");
                int statOfPlayer = 0;
                try {
                    statOfPlayer = scnr.nextInt();
                } catch (InputMismatchException e) {
                    System.err.println("Invalid value, try again.");
                    scnr.nextLine();
                    continue;
                }
                System.out.println("Enter this player's last name");
                String playerName = scnr.next();
                playerNames[i] = playerName;
                test.writeToFile(statOfPlayer, playerName);
                //Stores each player's stat in order to find the maximum
                playerStats[i] = statOfPlayer;
                ++i;
            }
            test.findMax(playerStats, playerNames, statCategory);
            System.out.println("Is the data on the file correct? Type \'n\' to clear ");

            String userResponse = String.valueOf(scnr.next().charAt(0));
            if (userResponse.equalsIgnoreCase("n"))
            {
                test.clearFile();
                System.out.println("Data was cleared.");
            } else
            {
                System.out.println("Data was left as is.");
            }
            System.out.println("Are there more stats to input? Type 'n' to finish");
            char stopCheck;
            try
            {
                stopCheck = scnr.next().toLowerCase().charAt(0);
            }
            catch (InputMismatchException e)
            {
                System.err.println("Invalid value, try again.");
                scnr.nextLine();
                continue;
            }
            if (stopCheck == 'n')
            {
                stopCondition = false;
            }


        }
    }
}